﻿using System;
using System.Collections.Generic;

namespace Excercise_1
{
    public class ComposedMission : IMission
    {
        private LinkedList<CalcDelegate> calculators;
        private string name;
        private string type;

        public ComposedMission(string name)
        {
            this.name = name;
            this.type = "Composed";
            calculators = new LinkedList<CalcDelegate>();
        }

        public ComposedMission Add(CalcDelegate calc)
        {
            calculators.AddLast(calc);
            return this;
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Type
        {
            get { return type; }
            set { type = value;
            }
        }

        public event EventHandler<double> OnCalculate;

        public double Calculate(double value)
        {
            foreach (CalcDelegate c in calculators)
            {
                value = c(value);
            }

            OnCalculate?.Invoke(this, value);

            return value;
        }
    }
}