﻿using System.Collections.Generic;

namespace Excercise_1
{
    public delegate double CalcDelegate(double x);

    public class FunctionsContainer
    {
        private Dictionary<string, CalcDelegate> dict = new Dictionary<string, CalcDelegate>();

        public CalcDelegate this[string index]
        {
            get
            {
                if (!(dict.ContainsKey(index)))
                {
                    return val => val;
                }
                return dict[index];
            }
            set { dict[index] = value; }
        }
    }
}