﻿using System;

namespace Excercise_1
{
    public class SingleMission : IMission
    {
        private CalcDelegate calc;
        private string name;
        private string type;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public SingleMission(CalcDelegate calc, string name)
        {
            this.name = name;
            this.type = "Single";
            this.calc = calc;
        }

        public event EventHandler<double> OnCalculate;

        public double Calculate(double value)
        {
            value = calc(value);
            OnCalculate?.Invoke(this, value);
            return value;
        }
    }
}